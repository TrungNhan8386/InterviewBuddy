INTERVIEWBUDDY - TEST DATA PACKAGE (UC-01 to UC-06)
===================================================
All names, emails and phone numbers are fictional. The files are meant for the test cases in
InterviewBuddy_Test_Cases_UC01-UC06.xlsx. Do not use real personal data on the staging site.

FOLDERS
-------
jd/                      Job descriptions (plain text, ASCII only, exact character counts)
  jd_valid.txt              Frontend Developer Intern JD (valid, about 850 characters)  -> UC04-01, 02, 04, 05
  jd_29chars.txt            29 characters  (Analyze must stay disabled)                  -> UC04-03
  jd_30chars.txt            30 characters  (smallest valid JD)                           -> UC04-03
  jd_3000chars.txt          3,000 characters (largest valid JD)                          -> UC04-03
  jd_3100chars.txt          3,100 characters (100 over the limit)                        -> UC04-03
  The 4 length files are one single line with no line breaks, so the counter is exact.

cv/                      CV files
  cv_valid.pdf              Text-based PDF, 2 pages, small size                          -> UC04-01, 04, 05, UC05, UC06
  cv_valid.txt              Same CV as plain text for pasting                            -> UC04-02 step 6
  cv_valid_vi.pdf           Vietnamese CV (diacritics) to check text extraction          -> optional extra for UC04-01
  cv.docx                   Word file (not a PDF)                                        -> UC04-02 step 1
  cv_big.pdf                About 8 MB valid PDF (over 5 MB)                             -> UC04-02 step 2
  cv_scanned.pdf            PDF with images only, no text                                -> UC04-02 step 3
  cv_locked.pdf             Password-protected PDF (password if the page asks: 123456)   -> UC04-02 step 4
  cv_corrupt.pdf            Damaged PDF (cannot be opened)                               -> UC04-02 step 5
  cv_29chars.txt            CV text of 29 characters                                     -> UC04-03 step 5
  cv_long_20k_plus.txt      About 20,300 characters; the line starting with
                            AFTER-LIMIT-MARKER is after character 20,000, so the analysis
                            must not mention Kubernetes or Terraform                     -> UC04-03 step 6

  Expected fit of cv_valid vs jd_valid (to judge the AI result, which may vary):
    matched : HTML, CSS, JavaScript, Git, React (basic), REST API, English reading
    partial : React experience (only course projects), teamwork (club projects)
    missing : TypeScript, unit testing (Jest), Figma-to-code work experience

interview/
  answer_bank.txt          Ready-made answers for UC-06 (vague, unclear term, "I don't know",
                            good technical/behavioral answers, whitespace, off-topic, long)

accounts_and_inputs/
  input_values.txt         Emails, passwords, 120/121/200-character strings, profile values
  accounts_template.csv    Which test accounts to create and which cases use them
  target_position_120chars.txt / _121chars.txt / _200chars.txt   The same strings as separate files

TIPS
----
- Gmail plus-addressing (yourname+ib_a@gmail.com) lets one mailbox receive mail for many accounts.
- Create the accounts in accounts_template.csv first; UC04 and UC06 need a user who already has a saved analysis.
- Keep one shared copy of this folder on the team Google Drive so everyone tests with the same files.
- Do not upload real CVs (yours or other people's) to the staging site.
