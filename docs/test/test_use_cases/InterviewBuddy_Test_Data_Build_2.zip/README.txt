InterviewBuddy - Shared test data for Build 2 (UC-07, UC-08, UC-09, UC-10, UC-17)

accounts_and_inputs/  test accounts and the texts typed into the delete confirmation box
interview/            interview questions and typed answers
voice/                short scripts to READ ALOUD into the microphone (UC-07). They are text, not audio.
seed/                 seed_data.sql (Supabase SQL editor, built from the SAD v1.1 ERD, NOT yet run) and
                      seed_sessions.md (what each session/report must contain)

The file names and IDs (S1, S2, ... R-B, SHARE-01, VOICE-01 ...) match the "Test data" sheet and the
"Test cases" sheet of InterviewBuddy_Test_Cases_UC07-08-09-10-17.xlsx.
Accounts must be created on staging through Sign up (UC-01) before use.
