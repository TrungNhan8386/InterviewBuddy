# Seed data to prepare before testing

Build the data with seed/seed_data.sql (Supabase SQL editor, after the 5 accounts exist). The script is written from the SAD v1.1 ERD and has NOT been run yet; its header lists what to check. It only seeds what the Build 1 schema can store.

**Not seedable yet (no table/column in SAD v1.1):** strengths / areas-to-improve text, the report summary, practice sessions, practice questions (UC-10), bookmarks, practice plan, the daily AI-call counter. These are created by the features themselves (Build 2) or must be added after the Build 2 migrations.

## 1. Sessions of candidate_a
| ID | Type | State | Required content | Used in |
|---|---|---|---|---|
| S1 | Behavioral, English, 15 min (5 planned main questions) | completed | 5 main questions + 1 follow-up, answered by voice, all feedback saved. Scores: Content 7, STAR 6, Clarity 8, Confidence 7. An earlier completed session with a report must exist (for the improvement trend). NO report yet: UC09-01 builds it; UC09-03 and UC08-04 run after UC09-01. | UC09-01, 03, UC08-04 |
| S2 | Technical, English | completed | 5 TYPED answers (no durations), all scored (Content, Clarity, Confidence; no STAR). | UC09-02 |
| S5 | Behavioral | completed | Scored answers but NO report built yet. Open its report while the AI is blocked. | UC09-05 |
| S7 | Behavioral | completed | Answers saved but every feedback is marked failed (no score at all). | UC09-07 |
| S8 | Behavioral | report built | Scores Content 9, STAR 8, Clarity 8, Confidence 8. No practice questions yet. | UC10-04 |
| S10 | Behavioral | report built | Scores Content 7, STAR 8, Clarity 4, Confidence 5. No practice questions yet. Keep fresh copies for UC10-05 and UC10-06 (generated questions are saved after the first success). | UC10-01, 02, 03, 05, 06 |

## 2. Other accounts
- candidate_first: S4 = first completed session, ended early after 1 answer; the last question has NO answer. No earlier report.
- candidate_b: one completed session with a report. Its id is R-B (needed for UC09-06).

## 3. candidate_del (UC-17)
- 1 CV + job description analysis (fit_analyses)
- 3 completed interview sessions with answers, feedback and reports (2 with reports, 1 without)
- 1 report with share token SHARE01-test-token-0000000000000001 = SHARE-01
- Practice sessions, bookmarks and plan: add when those tables exist
- Expected message after deletion: number of deleted sessions (3 with this seed; confirm whether practice sessions are counted)
- Deletion calls DELETE /api/settings/data -> SQL delete_own_practice_data. All environments share ONE Supabase project, so only run it with candidate_del.
Create a copy of this data again before every run that deletes it (UC17-01, UC17-05).

## 4. Environment
- AI failure: set GEMINI_TIMEOUT_MS=1 (forces a time-out) or an invalid GEMINI_API_KEY on local/preview: UC08-06, UC09-05, UC10-05
- Daily AI limit: 100 AI calls per user per day, reset 00:00 Vietnam time (consume_ai_call, SAD): UC08-07, UC10-06
- Fixed-limit note: ask Nhan whether the limit can be lowered on the test environment
- Browsers: Chrome/Edge for voice; Firefox or Safari for the "not supported" case (UC07-02)
