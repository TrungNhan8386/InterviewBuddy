-- InterviewBuddy - seed data for the Build 2 test cases (UC-07, 08, 09, 10, 17)
-- Source of the table/column names: SAD v1.1, Figure 7 (ERD) and Table 5.
--
-- !! NOT YET RUN on the real database. Check before using:
--   1. Values that the real CHECK constraints may reject: round_type ('behavioral','technical'),
--      difficulty ('medium'), language ('en','vi'), input_mode ('voice','text'), status ('completed','in_progress'),
--      questions.kind ('main'). Change the values in the 'config' block below if the migrations use others.
--   2. reports.criteria_scores / speaking_metrics are jsonb; the key names below are a GUESS
--      (content, structure, clarity, confidence / filler_words, pace_wpm, avg_answer_words).
--   3. feedbacks: structure_score = NULL for Technical sessions (no STAR). If the column is NOT NULL, adjust.
--   4. The ERD has no column for strengths / areas to improve / report summary, no practice-session flag,
--      practice questions, bookmarks or AI-call counter. Those parts of the cases cannot be seeded from this
--      script (see seed_sessions.md).
--   5. A failed feedback is represented here as "answer without a feedbacks row" (S7).
--
-- HOW TO RUN: (a) create the 5 accounts in accounts.txt through Sign up first;
-- (b) paste this file in the Supabase SQL editor (runs as postgres, so RLS is bypassed).
-- The staging environment shares ONE Supabase project (SAD section 5): this script only touches the five
-- candidate_*@test.com accounts.  Run it again to reset them (it deletes their sessions first).

create or replace function pg_temp.seed_session(
  p_user uuid, p_round text, p_lang text, p_duration int, p_input text, p_status text,
  p_answers int, p_scores int[],            -- {content, structure, clarity, confidence}; structure NULL = technical
  p_with_feedback boolean, p_with_report boolean, p_started timestamptz,
  p_extra_open_question boolean default false, p_share_token text default null
) returns uuid language plpgsql as $$
declare
  sid uuid := gen_random_uuid(); qid uuid; aid uuid; i int; n_crit int; overall numeric;
begin
  insert into interview_sessions(id,user_id,round_type,difficulty,language,target_position,interview_date,
      duration_minutes,input_mode,planned_questions,status,jd_text,cv_text,started_at,ended_at)
  values (sid,p_user,p_round,'medium',p_lang,'Frontend Developer Intern',current_date,
      p_duration,p_input,case p_duration when 15 then 5 when 30 then 8 else 12 end,p_status,
      'Seed JD text','Seed CV text',p_started,
      case when p_status='completed' then p_started + make_interval(mins => p_duration) end);

  n_crit := (select count(*) from unnest(p_scores) s where s is not null);
  overall := round((select sum(s) from unnest(p_scores) s)::numeric / n_crit, 1);

  for i in 1..p_answers loop
    qid := gen_random_uuid(); aid := gen_random_uuid();
    insert into questions(id,session_id,position,kind,topic,content)
      values (qid,sid,i,'main','seed topic '||i,'Seed question '||i||'?');
    insert into answers(id,question_id,content,input_mode,duration_seconds,word_count)
      values (aid,qid,'Seed answer '||i||'. In my project I solved a problem and the result was good.',
              p_input,case when p_input='voice' then 45 end,16);
    if p_with_feedback then
      insert into feedbacks(id,answer_id,content_score,structure_score,clarity_score,confidence_score,overall_score,next_action)
        values (gen_random_uuid(),aid,p_scores[1],p_scores[2],p_scores[3],p_scores[4],overall,'next_topic');
    end if;
  end loop;

  if p_extra_open_question then            -- last question asked but not answered (S4)
    insert into questions(id,session_id,position,kind,topic,content)
      values (gen_random_uuid(),sid,p_answers+1,'main','seed topic open','Seed unanswered question?');
  end if;

  if p_with_report then
    insert into reports(id,session_id,overall_score,criteria_scores,speaking_metrics,share_token)
      values (gen_random_uuid(),sid,overall,
        jsonb_build_object('content',p_scores[1],'structure',p_scores[2],'clarity',p_scores[3],'confidence',p_scores[4]),
        jsonb_build_object('filler_words',6,'pace_wpm',case when p_input='voice' then 130 end,'avg_answer_words',16),
        p_share_token);
  end if;
  return sid;
end $$;

do $$
declare
  ua uuid := (select id from auth.users where email='candidate_a@test.com');
  ub uuid := (select id from auth.users where email='candidate_b@test.com');
  uf uuid := (select id from auth.users where email='candidate_first@test.com');
  ud uuid := (select id from auth.users where email='candidate_del@test.com');
  ue uuid := (select id from auth.users where email='candidate_empty@test.com');
  s uuid;
begin
  if ua is null or ub is null or uf is null or ud is null or ue is null then
    raise exception 'Create the 5 candidate_*@test.com accounts through Sign up first';
  end if;

  -- reset (cascade expected from interview_sessions; if not, delete child rows first)
  delete from interview_sessions where user_id in (ua,ub,uf,ud,ue);
  delete from fit_analyses       where user_id in (ua,ub,uf,ud,ue);

  -- candidate_a ---------------------------------------------------------------------------------
  -- S0: earlier completed session WITH report, so that S1 has a trend to compare with
  perform pg_temp.seed_session(ua,'behavioral','en',15,'voice','completed',5,array[6,5,7,6],true,true, now()-interval '10 days');
  -- S1: Behavioral 15 min, voice, scores C7 S6 Cl8 Cf7, feedback saved, NO report (built by UC09-01)
  s := pg_temp.seed_session(ua,'behavioral','en',15,'voice','completed',5,array[7,6,8,7],true,false, now()-interval '5 days');
  raise notice 'S1 session id = %', s;
  -- S2: Technical, typed answers, no STAR, scored, no report
  s := pg_temp.seed_session(ua,'technical','en',15,'text','completed',5,array[7,null,6,6],true,false, now()-interval '4 days');
  raise notice 'S2 session id = %', s;
  -- S5: completed, scored, NO report (open it with the AI blocked)
  s := pg_temp.seed_session(ua,'behavioral','en',15,'text','completed',4,array[7,6,7,6],true,false, now()-interval '3 days');
  raise notice 'S5 session id = %', s;
  -- S7: completed, every feedback failed (answers without feedbacks rows)
  s := pg_temp.seed_session(ua,'behavioral','en',15,'text','completed',4,array[0,0,0,0],false,false, now()-interval '2 days');
  raise notice 'S7 session id = %', s;
  -- S8: report with Content 9, STAR 8, Clarity 8, Confidence 8 (tie-break case)
  s := pg_temp.seed_session(ua,'behavioral','en',15,'text','completed',5,array[9,8,8,8],true,true, now()-interval '2 days');
  raise notice 'S8 session id = %', s;
  -- S10: report with Content 7, STAR 8, Clarity 4, Confidence 5 (make 3 copies: UC10-01/02/03, UC10-05, UC10-06)
  for i in 1..3 loop
    s := pg_temp.seed_session(ua,'behavioral','en',15,'text','completed',5,array[7,8,4,5],true,true, now()-interval '1 day');
    raise notice 'S10 copy % session id = %', i, s;
  end loop;

  -- candidate_first: S4 = first and only session, ended early after 1 answer, last question unanswered
  s := pg_temp.seed_session(uf,'behavioral','en',15,'text','completed',1,array[6,5,6,6],true,false, now()-interval '1 day', true);
  raise notice 'S4 session id = %', s;

  -- candidate_b: one completed session with a report (R-B)
  s := pg_temp.seed_session(ub,'behavioral','en',15,'text','completed',5,array[7,7,7,7],true,true, now()-interval '1 day');
  raise notice 'R-B session id = %', s;

  -- candidate_del: UC-17 data (rebuild with this script before every run that deletes it)
  insert into fit_analyses(id,user_id,jd_text,cv_text,cv_file_name,language,fit_score,result)
    values (gen_random_uuid(),ud,'Seed JD text','Seed CV text','cv_seed.pdf','en',72,'{}'::jsonb);
  perform pg_temp.seed_session(ud,'behavioral','en',15,'voice','completed',5,array[7,6,8,7],true,true, now()-interval '6 days');
  perform pg_temp.seed_session(ud,'technical','en',15,'text','completed',5,array[6,null,6,5],true,true, now()-interval '4 days',false,'SHARE01-test-token-0000000000000001');
  perform pg_temp.seed_session(ud,'behavioral','vi',15,'text','completed',3,array[5,5,6,5],true,false, now()-interval '2 days');
  -- SHARE-01 = report share_token 'SHARE01-test-token-0000000000000001' of the Technical session above

  -- candidate_empty: nothing to insert
end $$;
